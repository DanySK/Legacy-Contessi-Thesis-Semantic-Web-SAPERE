/** Automatically generated file. DO NOT MODIFY */
package it.apice.sapere.node.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}